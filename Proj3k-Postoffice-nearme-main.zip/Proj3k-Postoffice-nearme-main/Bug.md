#User.h
-ถ้ากรอก Username แล้ว spacebar มันจะนับตัวหลัง spacebar เป็น password
สวัสดีคับสมาชิกชมรมคนชอบหี